module.exports = {
    dialect: 'mysql',
    host: 'localhost',
    username: 'root',
    password: 'Root@123',
    database: 'crudenode',
    define:{
        timestamps: true,
        underscored: true,
    },
};
